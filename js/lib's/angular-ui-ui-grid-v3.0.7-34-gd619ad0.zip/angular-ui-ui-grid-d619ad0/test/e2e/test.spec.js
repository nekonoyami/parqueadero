describe('angularjs homepage', function() {
  
});