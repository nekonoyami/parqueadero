module.exports = {
  options: {
    dest: 'CHANGELOG.md',
    github: 'angular-ui/ng-grid'
  }
};
